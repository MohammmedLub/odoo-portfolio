# 🎫 Ticket SALES-002: Wrong VAT on EU Customer Invoice

## Ticket Information

| Field | Value |
|-------|-------|
| **Ticket ID** | SALES-002 |
| **Priority** | P2 - High |
| **Category** | Configuration Issue |
| **Status** | ✅ RESOLVED |
| **Created** | 2026-01-15 11:00 |
| **Resolved** | 2026-01-15 12:30 |
| **Resolution Time** | 1.5 hours |

---

## 📝 Customer Report

**From:** Accounting - Thomas Leroy  
**Subject:** Incorrect VAT on French customer invoice

> Hello,
>
> I created an invoice for our French customer TotalEnergies SE and the system 
> applied Belgian VAT 21% instead of 0% for intra-community sales.
>
> The customer has a valid French VAT number (FR05542051180) so this should 
> be reverse charge with 0% VAT.
>
> Please help ASAP as this affects our VAT declaration.
>
> Thomas

---

## 🔍 Investigation

### Step 1: Verify Customer Data

**Navigation:** Contacts → TotalEnergies SE

| Field | Value | Status |
|-------|-------|--------|
| Company Name | TotalEnergies SE | ✓ |
| Country | France | ✓ |
| VAT Number | FR05542051180 | ✓ Valid |
| **Fiscal Position** | *(not set)* | ❌ MISSING |

### Step 2: Check Invoice

**Navigation:** Comptabilité → Factures clients → INV/2026/00004

| Line | Product | Quantity | Unit Price | **Tax Applied** |
|------|---------|----------|------------|-----------------|
| 1 | Office Chair | 10 | €120.00 | **21% TVA** ❌ |
| 2 | Support Contract | 1 | €500.00 | **21% TVA** ❌ |

**Problem Confirmed:** Belgian VAT 21% applied instead of 0% intra-community

### Step 3: Root Cause Analysis

```
TAX DETERMINATION FLOW IN ODOO:
────────────────────────────────

┌─────────────────┐
│  Product Tax    │  Default: 21% TVA Vente
│  (Default)      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Customer Fiscal │  ← NOT SET for TotalEnergies!
│    Position     │  
└────────┬────────┘
         │ If set, maps taxes:
         │ 21% → 0% (Intra-EU)
         ▼
┌─────────────────┐
│   Final Tax     │  Currently: 21% (wrong)
│   on Invoice    │  Should be: 0%
└─────────────────┘
```

| Category | Classification |
|----------|----------------|
| **Type** | FUNCTIONAL - Configuration |
| **Root Cause** | Customer missing fiscal position assignment |
| **Impact** | Incorrect VAT declaration, customer overcharged |
| **Escalation** | Not required (L1 resolution) |

---

## ✅ Resolution

### Step 1: Configure Fiscal Position on Customer

```
Navigation: Contacts → TotalEnergies SE → Edit
Tab: Ventes & Achats
Field: Position fiscale → Select "Intra-Community B2B"
Save
```

**Fiscal Position Mapping:**

| From Tax | To Tax | Condition |
|----------|--------|-----------|
| 21% TVA Vente | 0% Intra-EU | EU company with valid VAT |
| 21% TVA Achat | 0% Intra-EU | EU company with valid VAT |

### Step 2: Correct Existing Invoice

**Option A: Credit Note (Recommended)**
```
1. Comptabilité → INV/2026/00004
2. Click "Ajouter une note de crédit"
3. Reason: "Correction TVA - Position fiscale incorrecte"
4. Create credit note for full amount
5. Post credit note
6. Create new invoice (fiscal position now applies)
```

**Option B: Reset to Draft (if not yet sent)**
```
1. Comptabilité → INV/2026/00004
2. Click "Remettre en brouillon"
3. Edit invoice → Recalculate taxes
4. Verify 0% applied
5. Post invoice
```

### Step 3: Verify Correction

**New Invoice After Fix:**

| Line | Product | Quantity | Unit Price | **Tax Applied** |
|------|---------|----------|------------|-----------------|
| 1 | Office Chair | 10 | €120.00 | **0% Intra-EU** ✓ |
| 2 | Support Contract | 1 | €500.00 | **0% Intra-EU** ✓ |

**Totals:**
- Subtotal HT: €1,700.00
- VAT 0%: €0.00
- **Total: €1,700.00**

---

## 📊 Before & After Comparison

| Aspect | Before (Wrong) | After (Correct) |
|--------|----------------|-----------------|
| Tax Rate | 21% | 0% |
| Tax Amount | €357.00 | €0.00 |
| Total TTC | €2,057.00 | €1,700.00 |
| VAT Declaration | Belgian VAT due | Reverse charge (customer declares) |

---

## 📧 Customer Communication

**To:** Thomas Leroy  
**Subject:** RE: Incorrect VAT on French customer invoice - RESOLVED

> Hi Thomas,
>
> I've investigated and resolved the VAT issue. Here's what happened:
>
> **Root Cause:**
> The customer TotalEnergies SE did not have a fiscal position assigned. 
> Without this configuration, Odoo applies the default product tax (21% Belgian VAT).
>
> **Resolution Applied:**
> 1. Assigned fiscal position "Intra-Community B2B" to TotalEnergies SE
> 2. This maps Belgian 21% VAT → 0% for intra-EU B2B sales
> 3. Created credit note CN/2026/00008 for the incorrect invoice
> 4. Created corrected invoice INV/2026/00005 with 0% VAT
>
> **Documents:**
> - Original invoice INV/2026/00004: Cancelled
> - Credit note CN/2026/00008: €2,057.00
> - New invoice INV/2026/00005: €1,700.00 (0% VAT)
>
> **For future EU customers:**
> When creating a new customer with an EU VAT number, please assign the 
> appropriate fiscal position in the "Ventes & Achats" tab.
>
> The VAT declaration impact has been corrected. Please let me know if you 
> need any additional documentation.
>
> Best regards,
> Support Team

---

## 🛡️ Prevention Measures

| Action | Owner | Status |
|--------|-------|--------|
| Create automation to suggest fiscal position based on country | Admin | In Progress |
| Add fiscal position to customer creation checklist | Training | Completed |
| Periodic audit of EU customers without fiscal position | Accounting | Monthly |
| Document fiscal position rules in knowledge base | Support | Completed |

### Automation Rule (Proposed)

```python
# Automation: Auto-assign fiscal position for EU companies

trigger: On creation of res.partner (is_company=True)

conditions:
  - partner.country_id.code IN ['FR', 'DE', 'NL', 'IT', 'ES', ...]
  - partner.country_id.code != 'BE'
  - partner.vat IS NOT NULL

action:
  - partner.property_account_position_id = 'Intra-Community B2B'
  - Log: "Fiscal position auto-assigned based on EU country"
```

---

## 📚 Knowledge Base Update

**Article Created:** KB-2026-005 - Fiscal Position for EU Customers

> **Problem:** Belgian VAT applied to EU B2B customers
>
> **Cause:** Fiscal position not assigned on customer record
>
> **Solution:** 
> 1. Contacts → Customer → Edit
> 2. Tab "Ventes & Achats"
> 3. Set "Position fiscale" = Intra-Community B2B
> 4. Recreate or update invoice
>
> **Fiscal Positions Available:**
> - Belgian VAT (default) - for Belgian customers
> - Intra-Community B2B - for EU companies with valid VAT
> - Export (Extra-EU) - for customers outside EU
>
> **Related:** See VAT validation guide KB-2026-006

---

## 📊 Ticket Metrics

| Metric | Value |
|--------|-------|
| First Response Time | 20 minutes |
| Resolution Time | 1.5 hours |
| Customer Satisfaction | ⭐⭐⭐⭐⭐ (5/5) |
| Escalation | None |
| Reopened | No |

---

*Ticket closed: 2026-01-15 12:30*
