# 🎫 Complex Case Study: Pricing Rules Not Stacking

## Ticket Information

| Field | Value |
|-------|-------|
| **Ticket ID** | PRICING-001 |
| **Priority** | P2 - High |
| **Category** | Configuration Issue |
| **Status** | ✅ RESOLVED |
| **Resolution Time** | 4.5 hours |
| **Escalation** | None (L1 resolved) |

---

## 📝 Customer Report

**From:** Finance Director - EuroTech Solutions GmbH  
**Subject:** Pricing rules not applying correctly - wrong prices on invoices

> We have set up complex pricing rules in Odoo Sales for our product catalog:
>
> 1. **Customer Segment Pricing:**
>    - Gold customers: 15% discount
>    - Silver customers: 10% discount
>    - Bronze customers: 5% discount
>
> 2. **Quantity Discounts:**
>    - 10-49 units: 5% off
>    - 50-99 units: 10% off
>    - 100+ units: 15% off
>
> 3. **Seasonal Promotion (Jan 1-31):**
>    - Winter Sale: Additional 10% off
>
> **PROBLEM:** Our Gold customer "MegaCorp" ordered 75 units of Product SKU-1001.
> - Expected discount: 15% (Gold) + 10% (qty 50-99) + 10% (Winter) = **35% total**
> - Actual discount applied: **Only 10%**
>
> This has happened on 3 invoices this week!

---

## 🔍 Investigation

### Step 1: Review Pricelist Configuration

**Navigation:** Sales → Configuration → Pricelists → Gold Pricelist → Price Rules

**Discovered Rules:**

| Sequence | Rule Name | Discount | Min Qty | Dates | Status |
|----------|-----------|----------|---------|-------|--------|
| 5 | Qty Discount 10-49 | 5% | 10 | Always | Active |
| 5 | Qty Discount 50-99 | 10% | 50 | Always | Active |
| 5 | Qty Discount 100+ | 15% | 100 | Always | Active |
| 10 | Gold Customer | 15% | 1 | Always | Active |
| 10 | Silver Customer | 10% | 1 | Always | Active |
| 10 | Bronze Customer | 5% | 1 | Always | Active |
| 20 | Winter Sale | 10% | 1 | Jan 1-31 | Active |

### Step 2: Understand Rule Evaluation

```
CRITICAL FINDING: ODOO PRICELISTS DON'T STACK!
══════════════════════════════════════════════

Odoo applies only ONE pricelist rule - the FIRST matching rule based on sequence.

Current evaluation order:

┌───────────────────────────────────────────────────────────┐
│  SEQUENCE 5 (Highest Priority)                            │
│  └─► Qty Discounts evaluated FIRST                        │
│      • For 75 units → "Qty Discount 50-99" matches        │
│      • 10% discount applied                               │
│      • PROCESSING STOPS HERE!                             │
├───────────────────────────────────────────────────────────┤
│  SEQUENCE 10 (Never reached)                              │
│  └─► Customer Segment Discounts                           │
│      • Gold 15% - NOT EVALUATED                           │
├───────────────────────────────────────────────────────────┤
│  SEQUENCE 20 (Never reached)                              │
│  └─► Winter Sale 10% - NOT EVALUATED                      │
└───────────────────────────────────────────────────────────┘

RESULT: Customer gets 10% instead of expected 35%
```

### Step 3: Verify Customer Assignment

**Navigation:** Contacts → MegaCorp

| Field | Value | Status |
|-------|-------|--------|
| Customer Segment | Gold | ✓ |
| **Pricelist** | **Public Pricelist** | ❌ WRONG! |

**FINDING:** MegaCorp assigned to wrong pricelist!

### Step 4: Reproduce Issue

```
Test Case: Create quotation for MegaCorp, 75 units

Expected (if stacking worked): 35% = €4,875 (75 × €100 × 0.65)
Actual (single rule):         10% = €6,750 (75 × €100 × 0.90)
────────────────────────────────────────────────────────────
Difference: Customer overcharged €1,875
```

---

## 🎯 Root Cause Analysis

### Three Issues Identified:

| ID | Type | Issue | Impact |
|----|------|-------|--------|
| RC-1 | **Design** | Customer expects discount stacking, Odoo applies ONE rule | All calculations wrong |
| RC-2 | **Config** | Sequence values favor qty over customer segment | Wrong priority |
| RC-3 | **Data** | MegaCorp assigned to wrong pricelist | No segment discount |

### Classification

```
This is a FUNCTIONAL issue, NOT a bug.

Odoo is working as designed. The issue stems from:
• Misunderstanding of pricelist behavior
• Misconfiguration of rule priorities
• Data entry error on customer record

NO ESCALATION TO R&D REQUIRED.
```

---

## ✅ Resolution

### Fix 1: Correct Customer Pricelist Assignment

```
Contacts → MegaCorp → Edit
Tab: Ventes & Achats
Field: Liste de Prix → Change to "Gold Pricelist"
Save
```

### Fix 2: Create Combined Pricing Rules

Since stacking isn't automatic, create pre-calculated rules:

**New Rules for Gold Pricelist:**

| Rule Name | Discount | Min Qty | Max Qty | Dates | Sequence |
|-----------|----------|---------|---------|-------|----------|
| Gold + Qty 10-49 + Winter | 30% | 10 | 49 | Jan 1-31 | 1 |
| Gold + Qty 50-99 + Winter | 35% | 50 | 99 | Jan 1-31 | 1 |
| Gold + Qty 100+ + Winter | 40% | 100 | - | Jan 1-31 | 1 |
| Gold + Qty 10-49 | 20% | 10 | 49 | - | 2 |
| Gold + Qty 50-99 | 25% | 50 | 99 | - | 2 |
| Gold + Qty 100+ | 30% | 100 | - | - | 2 |
| Gold Base | 15% | 1 | - | - | 3 |

**Logic:** Most specific rules (with Winter Sale) have sequence 1, evaluated first.

### Fix 3: Correct Historical Invoices

```
Create credit notes for affected invoices:

INV/2025/0102 (MegaCorp):     Credit €1,875.00
INV/2025/0098 (TechStart):    Credit €375.00
INV/2025/0095 (SmallBiz):     Credit €562.50
──────────────────────────────────────────────
Total credit issued:          €2,812.50
```

---

## 📧 Customer Communication

**Subject:** RE: Pricing Rules Issue - RESOLVED

> Dear EuroTech Solutions Team,
>
> We've completed our investigation and resolved the pricing discrepancy.
>
> **ROOT CAUSE:**
> 1. MegaCorp was assigned to the wrong pricelist
> 2. Odoo's standard behavior applies only ONE pricelist rule (first match), 
>    not combined/stacked discounts
>
> **RESOLUTION:**
> ✓ MegaCorp pricelist corrected to Gold Pricelist
> ✓ Created combined pricing rules for all discount scenarios
> ✓ Credit notes issued for affected invoices (€2,812.50 total)
>
> **IMPORTANT NOTE:**
> Odoo pricelists use "first match wins" logic. To achieve discount stacking, 
> you must create combined rules with pre-calculated totals.
>
> Example: Gold (15%) + Qty 50-99 (10%) + Winter (10%) = Create rule with 35%
>
> Please let us know if you have questions.
>
> Best regards,
> Support Team

---

## 🛡️ Prevention

| Action | Owner | Status |
|--------|-------|--------|
| Customer onboarding: verify pricelist assignment | Sales | Implemented |
| Quarterly pricelist audit scheduled | Admin | Scheduled |
| Knowledge base article created | Support | Published |
| Training session for sales team | Training | Completed |
| Documentation of pricelist behavior | Support | Completed |

---

## 📚 Knowledge Base Article

**KB-2026-010: Understanding Odoo Pricelist Behavior**

> **Key Points:**
> 
> 1. Odoo pricelists apply ONE rule only (first match by sequence)
> 2. Discounts do NOT stack automatically
> 3. Lower sequence number = higher priority
> 4. Create combined rules for "stacking" behavior
> 5. Always verify customer pricelist assignment
>
> **Example:**
> - Wrong expectation: 15% + 10% + 10% = 35%
> - Actual behavior: Only first matching rule applies
> - Solution: Create single rule with 35% discount

---

## 🎓 Lessons Learned

1. **Always verify customer expectations** before configuring pricelists
2. **Document the limitation** that discounts don't stack
3. **Create combined rules** for complex discount scenarios
4. **Regular audits** of customer pricelist assignments
5. **Training is essential** when standard behavior differs from expectations

---

## 📊 Interview Summary

**How to explain this case:**

> "I resolved a complex pricing issue where customers expected multiple discounts 
> to stack (combine), but Odoo was only applying one discount.
>
> My investigation revealed three issues:
> 1. A data error - customer assigned to wrong pricelist
> 2. A design misunderstanding - Odoo applies one rule, not stacking
> 3. A configuration issue - rule sequences weren't optimized
>
> I resolved this by:
> 1. Correcting customer assignments
> 2. Creating combined pricing rules with pre-calculated totals
> 3. Issuing credit notes for affected invoices
> 4. Documenting the behavior in our knowledge base
>
> This case taught me the importance of understanding how Odoo actually works 
> versus how customers expect it to work."

---

*Case resolved: January 2026*
