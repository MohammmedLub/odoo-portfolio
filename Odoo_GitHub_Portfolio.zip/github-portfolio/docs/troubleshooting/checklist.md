# 🔧 CRM/Sales Troubleshooting Checklist

## Quick Diagnostic Guide

Use this checklist when investigating CRM and Sales issues.

---

## 🎯 CRM Issues

### Lead Won't Convert to Opportunity

- [ ] **Email or phone present?**
  - Location: Lead → Email / Phone fields
  - Fix: Add at least email or mobile phone

- [ ] **Lead already converted?**
  - Check: Lead → type field (should be 'lead', not 'opportunity')
  - If type='opportunity', it's already converted

- [ ] **User has CRM access?**
  - Check: Settings → Users → [User] → CRM group
  - Required: At least "CRM: User" group

- [ ] **Duplicate warning appearing?**
  - Normal behavior if contact exists
  - Solution: Choose "Merge" in dialog

### Pipeline Empty

- [ ] **Filter active?**
  - Check: Search bar for "Mon pipeline" filter
  - Fix: Remove filter to see all opportunities

- [ ] **User assigned to opportunities?**
  - Check: Opportunities → Vendeur field
  - Fix: Reassign opportunities to user

- [ ] **Correct sales team?**
  - Check: User belongs to team with opportunities
  - Location: CRM → Configuration → Teams

### Stage Not Changing

- [ ] **Access rights sufficient?**
  - "Own Documents Only" = can only move own opportunities
  - Fix: Change to "All Documents" or reassign ownership

- [ ] **Browser cache issue?**
  - Fix: Clear cache or try incognito mode

- [ ] **Automation blocking?**
  - Check: Settings → Automations for crm.lead

### Forecast Showing €0

- [ ] **Expected revenue filled?**
  - Check: Opportunity → Revenu espéré field
  - Must be > 0

- [ ] **Closing date set?**
  - Check: Opportunity → Date clôture prévue
  - Must be set and in forecast period

- [ ] **Correct report period?**
  - Check: Report date filters match opportunity dates

---

## 💰 Sales Issues

### Wrong Price on Quotation

- [ ] **Customer pricelist correct?**
  - Check: Contacts → Customer → Ventes & Achats → Liste de Prix
  - Fix: Assign correct pricelist

- [ ] **Pricelist rule conditions met?**
  - Check: Min quantity, date range, product category
  - Rules only apply if ALL conditions match

- [ ] **Rule sequence correct?**
  - Lower sequence = higher priority
  - First matching rule wins

### Cannot Confirm Quotation

- [ ] **Approval pending?**
  - Check: Banner "En attente d'approbation"
  - Fix: Get manager approval

- [ ] **Required fields missing?**
  - Check: Error messages on save
  - Common: Payment terms, delivery address

- [ ] **User has Sales access?**
  - Required: "Sales: User" or higher

- [ ] **Already confirmed?**
  - Check: state field (if 'sale', already confirmed)

### Wrong VAT Applied

- [ ] **Customer fiscal position set?**
  - Location: Contacts → Customer → Ventes & Achats → Position fiscale
  - For EU B2B: "Intra-Community B2B"
  - For non-EU: "Export"

- [ ] **Customer VAT number valid?**
  - Check: Contacts → Customer → VAT field
  - Format must be correct (e.g., FR12345678901)

- [ ] **Product tax configured?**
  - Check: Product → Taxes de vente
  - Default should be standard rate (21% for Belgium)

### Discount Not Showing

- [ ] **Discount feature enabled?**
  - Check: Ventes → Configuration → Paramètres → Remises
  - Must be checked/enabled

- [ ] **User can apply discounts?**
  - Check: User group allows discount entry
  - Some setups restrict discount entry

- [ ] **Discount within limit?**
  - If > limit, approval workflow may activate

### Invoice Button Greyed Out

- [ ] **Order confirmed?**
  - Check: state = 'sale' (not 'draft')
  - Fix: Confirm the order first

- [ ] **Invoicing policy = delivered?**
  - If "Quantités livrées", must validate delivery first
  - Check: Product → Politique de facturation

- [ ] **Delivery validated?**
  - Check: Inventaire → Livraisons
  - Status must be "Fait" (Done)

- [ ] **Already invoiced?**
  - Check: Smart button "Factures"
  - May already have invoice

### No Delivery Created

- [ ] **Products are storable?**
  - Check: Product → Type = "Biens" or "Consommable"
  - Services don't create deliveries

- [ ] **Route configured?**
  - Check: Product → Inventaire tab → Routes

---

## 🔍 General Checks

### User Can't See Records

- [ ] Access rights group assigned?
- [ ] Record rules not restricting?
- [ ] Domain filter active in search?
- [ ] Multi-company: correct company selected?

### Performance Issues

- [ ] Large dataset? Check pagination
- [ ] Complex computed fields? Check logs
- [ ] Scheduled actions running? Check cron

### Data Looks Wrong

- [ ] Correct database connected?
- [ ] Filters active in view?
- [ ] Archived records hidden?
- [ ] Date range appropriate?

---

## 📋 Information to Gather

When escalating, collect:

1. **Database name**
2. **User login/email**
3. **Odoo version**
4. **Steps to reproduce**
5. **Expected vs actual behavior**
6. **Screenshot of error**
7. **Recent changes made**

---

## 🚀 Quick Fixes

| Problem | First Try |
|---------|-----------|
| Can't see record | Remove filters |
| Can't edit record | Check access rights |
| Wrong price | Check pricelist assignment |
| Wrong tax | Check fiscal position |
| Button greyed | Check state/workflow |
| Error on save | Check required fields |
| Slow performance | Clear cache |

---

*Last updated: January 2026*
