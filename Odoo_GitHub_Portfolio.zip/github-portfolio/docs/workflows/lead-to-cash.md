# 💰 Lead to Cash Process Workflow

## Overview

The **Lead to Cash (L2C)** process covers the complete customer journey from initial contact to payment collection. This document details every step in Odoo.

---

## 📊 Process Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│                              LEAD TO CASH (L2C) COMPLETE FLOW                                   │
├─────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                 │
│  PHASE 1: LEAD MANAGEMENT (CRM)                                                                 │
│  ═══════════════════════════════                                                                │
│                                                                                                 │
│  ┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐              │
│  │    LEAD      │────►│  QUALIFIED   │────►│ OPPORTUNITY  │────►│   WON/LOST   │              │
│  │  (Piste)     │     │  (Qualifié)  │     │ (Opportunité)│     │ (Gagné/Perdu)│              │
│  │              │     │              │     │              │     │              │              │
│  │ crm.lead     │     │ crm.lead     │     │ crm.lead     │     │ crm.lead     │              │
│  │ type='lead'  │     │ type='opp'   │     │ type='opp'   │     │ prob=100/0   │              │
│  └──────────────┘     └──────────────┘     └──────────────┘     └──────────────┘              │
│         │                    │                    │                    │                       │
│         │ Capture            │ Convert            │ Progress           │ Close                 │
│         │ contact info       │ to opportunity     │ through stages     │ deal                  │
│         ▼                    ▼                    ▼                    ▼                       │
│  ┌──────────────────────────────────────────────────────────────────────────────────┐         │
│  │ KEY ACTIONS:                                                                      │         │
│  │ • Create/update res.partner (customer)                                           │         │
│  │ • Schedule activities (calls, meetings)                                          │         │
│  │ • Update expected revenue and probability                                        │         │
│  │ • Attach documents and notes                                                     │         │
│  └──────────────────────────────────────────────────────────────────────────────────┘         │
│                                                                                                 │
│                                           │                                                    │
│                                           │ If WON                                             │
│                                           ▼                                                    │
│                                                                                                 │
│  PHASE 2: QUOTATION (SALES)                                                                     │
│  ══════════════════════════                                                                     │
│                                                                                                 │
│  ┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐              │
│  │  QUOTATION   │────►│    SENT      │────►│   ACCEPTED   │────►│ SALES ORDER  │              │
│  │   (Devis)    │     │  (Envoyé)    │     │  (Accepté)   │     │ (Commande)   │              │
│  │              │     │              │     │              │     │              │              │
│  │ sale.order   │     │ sale.order   │     │ sale.order   │     │ sale.order   │              │
│  │ state=draft  │     │ state=sent   │     │ state=sent   │     │ state=sale   │              │
│  └──────────────┘     └──────────────┘     └──────────────┘     └──────────────┘              │
│         │                    │                    │                    │                       │
│         │ Add products       │ Email PDF          │ Customer           │ Confirm              │
│         │ Set prices         │ to customer        │ signs/accepts      │ order                │
│         ▼                    ▼                    ▼                    ▼                       │
│  ┌──────────────────────────────────────────────────────────────────────────────────┐         │
│  │ KEY ACTIONS:                                                                      │         │
│  │ • Apply pricelist rules                                                          │         │
│  │ • Calculate taxes (fiscal position)                                              │         │
│  │ • Apply discounts (approval if needed)                                           │         │
│  │ • Generate quotation PDF                                                         │         │
│  └──────────────────────────────────────────────────────────────────────────────────┘         │
│                                                                                                 │
│                                           │                                                    │
│                                           │ Confirmed                                          │
│                                           ▼                                                    │
│                                                                                                 │
│  PHASE 3: FULFILLMENT (INVENTORY + ACCOUNTING)                                                  │
│  ═════════════════════════════════════════════                                                  │
│                                                                                                 │
│       ┌──────────────────────────────────┬──────────────────────────────────┐                  │
│       │         PHYSICAL GOODS           │           SERVICES               │                  │
│       │                                  │                                  │                  │
│       ▼                                  │                                  ▼                  │
│  ┌──────────────┐                        │                        ┌──────────────┐            │
│  │   DELIVERY   │                        │                        │   INVOICE    │            │
│  │ (Livraison)  │                        │                        │  (Facture)   │            │
│  │              │                        │                        │              │            │
│  │ stock.picking│                        │                        │ account.move │            │
│  │ state=done   │                        │                        │ state=posted │            │
│  └──────┬───────┘                        │                        └──────┬───────┘            │
│         │                                │                               │                     │
│         │ Pick, pack, ship               │                               │ Send to customer    │
│         │ Update inventory               │                               │ Record in accounting│
│         ▼                                │                               ▼                     │
│  ┌──────────────┐                        │                        ┌──────────────┐            │
│  │   INVOICE    │◄───────────────────────┘                        │   PAYMENT    │            │
│  │  (Facture)   │                                                 │  (Paiement)  │            │
│  │              │                                                 │              │            │
│  │ account.move │────────────────────────────────────────────────►│ account.     │            │
│  │ state=posted │                                                 │ payment      │            │
│  └──────────────┘                                                 └──────┬───────┘            │
│                                                                          │                     │
│                                                                          │ Bank reconciliation │
│                                                                          ▼                     │
│                                                                   ┌──────────────┐            │
│                                                                   │  RECONCILED  │            │
│                                                                   │  (Lettré)    │            │
│                                                                   │              │            │
│                                                                   │ Invoice paid │            │
│                                                                   │ status=paid  │            │
│                                                                   └──────────────┘            │
│                                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 📋 Detailed Steps

### Phase 1: Lead Management

#### Step 1.1: Lead Creation

| Method | Description | Odoo Action |
|--------|-------------|-------------|
| Website Form | Customer fills contact form | Auto-creates crm.lead |
| Email Alias | Email to leads@company.com | Auto-creates crm.lead |
| Manual Entry | Sales rep creates lead | CRM → Leads → Create |
| Import | Bulk import from file | CRM → Import |

**Required Fields:**
- Contact Name
- Company (optional)
- Email OR Phone (for conversion)
- Expected Revenue (for forecast)

#### Step 1.2: Lead Qualification

**Qualification Checklist:**
- [ ] Contact is reachable (email/phone valid)
- [ ] Budget is identified
- [ ] Timeline is defined
- [ ] Decision maker identified
- [ ] Needs are documented

**Conversion:**
```
CRM → Lead → "Convertir en opportunité"
Options:
  - Create new customer (res.partner)
  - Link to existing customer
  - Merge with existing opportunity
```

#### Step 1.3: Opportunity Progression

| Stage | Criteria | Actions |
|-------|----------|---------|
| Nouveau | Initial contact | First call scheduled |
| Qualifié | Needs confirmed | Demo scheduled |
| Proposition | Quotation sent | Follow-up activity |
| Négociation | Customer reviewing | Address objections |
| Gagné | Deal closed | Create sales order |
| Perdu | Deal lost | Record lost reason |

---

### Phase 2: Quotation Management

#### Step 2.1: Create Quotation

**Navigation:** Ventes → Devis → Nouveau

**From Opportunity:** CRM → Opportunity → "Nouveau Devis"

**Quotation Header:**
| Field | Source | Example |
|-------|--------|---------|
| Customer | res.partner | My Office Inc |
| Pricelist | Customer default | B2B Belgium |
| Payment Terms | Customer default | 30 days |
| Validity | Settings | 30 days |
| Salesperson | Current user | Marc Dupont |

#### Step 2.2: Add Products

**Order Lines Configuration:**

```
Product Selection:
├── Search by name/code
├── Select variant (if applicable)
├── Set quantity
├── Verify unit price (from pricelist)
├── Apply discount (if authorized)
└── Taxes auto-calculated
```

**Price Determination:**
```
1. Product default price (list_price)
2. Pricelist rules applied (if match)
3. Discount applied (if authorized)
4. Taxes calculated (fiscal position mapping)
```

#### Step 2.3: Send Quotation

**Actions:**
1. Click "Envoyer par email"
2. Review email template
3. PDF attached automatically
4. Customer receives quotation
5. State changes to "Envoyé"

#### Step 2.4: Confirm Order

**Pre-confirmation Checks:**
- [ ] Customer approval received
- [ ] Discount within authorized limit
- [ ] Payment terms agreed
- [ ] Delivery date confirmed

**Confirmation:**
```
Ventes → Devis → [Select] → "Confirmer"

Results:
- state: draft → sale
- Delivery order created (if storable products)
- Invoice ready (based on policy)
- Opportunity marked as Won
```

---

### Phase 3: Fulfillment

#### Step 3.1: Delivery (Physical Goods)

**Navigation:** Inventaire → Livraisons

**Process:**
1. **Check Availability** - Verify stock
2. **Reserve** - Lock stock for order
3. **Pick** - Locate items in warehouse
4. **Pack** - Prepare for shipping
5. **Validate** - Confirm dispatch
6. **Track** - Update tracking number

**Delivery States:**
| State | Meaning |
|-------|---------|
| Brouillon | Not yet confirmed |
| En attente | Waiting for stock |
| Prêt | Ready to pick |
| Fait | Delivered |

#### Step 3.2: Invoice Creation

**Invoicing Policies:**

| Policy | When Invoice Created | Use Case |
|--------|---------------------|----------|
| Ordered Quantities | After SO confirmation | Services, prepayment |
| Delivered Quantities | After delivery validation | Physical goods |

**Navigation:** Ventes → Commandes → [Order] → "Créer une facture"

**Invoice Types:**
- Regular Invoice - Full order amount
- Down Payment (%) - Percentage advance
- Down Payment (Fixed) - Fixed amount advance

#### Step 3.3: Payment Collection

**Payment Methods:**
| Method | Odoo Configuration |
|--------|-------------------|
| Bank Transfer | Manual entry or bank sync |
| Credit Card | Payment acquirer integration |
| Cash | Cash journal |
| Check | Bank journal |

**Reconciliation:**
```
Comptabilité → Bank Statements → Import/Sync
└── Match payments to invoices
    └── Invoice status: Paid
```

---

## 📈 Key Metrics & Reports

### CRM Reports

| Report | Navigation | Purpose |
|--------|------------|---------|
| Pipeline | CRM → Analyse → Pipeline | Revenue by stage |
| Forecast | CRM → Analyse → Prévision | Expected revenue by period |
| Lead Analysis | CRM → Analyse → Pistes | Conversion rates |
| Activities | CRM → Analyse → Activités | Team productivity |

### Sales Reports

| Report | Navigation | Purpose |
|--------|------------|---------|
| Sales Analysis | Ventes → Analyse → Ventes | Revenue trends |
| Salesperson | Ventes → Analyse → Vendeurs | Individual performance |
| Product Sales | Ventes → Analyse → Produits | Product demand |

### Accounting Reports

| Report | Navigation | Purpose |
|--------|------------|---------|
| Invoices | Comptabilité → Analyse | AR aging |
| Payments | Comptabilité → Analyse | Cash flow |
| VAT Report | Comptabilité → Rapports | Tax declaration |

---

## ⚠️ Common Issues

| Issue | Root Cause | Solution |
|-------|------------|----------|
| Lead won't convert | Missing email/phone | Add contact info |
| Wrong price on quote | Pricelist not assigned | Set customer pricelist |
| Can't confirm order | Approval pending | Get manager approval |
| Invoice button grey | Policy = delivered, no delivery | Validate delivery first |
| Wrong VAT | Missing fiscal position | Assign fiscal position |
| No delivery created | Product type = service | Check product type |

---

## 🔗 Related Documents

- [CRM Pipeline Configuration](../config/crm-pipeline.md)
- [Pricelist Setup Guide](../config/pricelist-guide.md)
- [Fiscal Position Configuration](../config/fiscal-positions.md)
- [Troubleshooting Checklist](../troubleshooting/sales-checklist.md)

---

*Last updated: January 2026*
